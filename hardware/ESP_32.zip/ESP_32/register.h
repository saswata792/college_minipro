const char registered[]=
R"=====(
    <!Doctype html>
    <html>
    <head>
        <style>
            
        </style>
    </head>
    <body>
        <h1>Registered Successfully</h1>
 

  
   


    </body>
    </html>

)=====";
