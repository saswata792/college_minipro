const char changed[]=
R"=====(
    <!Doctype html>
    <html>
    <head>
        <style>
            
                
        </style>
    </head>
    <body>
        <form action="/changepro" >
            <button>Change/Update your Profile</button>
        </form>
        <form action="/changerout">
            <button>Change/Update your Router</button>
        </form>
   


    </body>
    </html>

)=====";
